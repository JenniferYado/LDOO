/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.AciertaModelo;

/**
 *
 * @author Jennifer Guadalupe González Yado
 */
public class AciertaControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String numero = request.getParameter("numero"); 
            int num1 = parseInt(numero);
            System.out.println("Adentro");
            AciertaModelo modelo = new AciertaModelo();
                       
            if(num1 >= 1 && num1 <=5 ){
                
                HttpSession session = request.getSession();
                
                Integer intentosSesion = (Integer)session.getAttribute("intentos"); 
                int intentos = (intentosSesion == null ? 0 : intentosSesion); 
                session.setAttribute("intentos", ++intentos);
                
                
                if (intentos == 1) {  
                    System.out.println("intento = 0");
                    System.out.println("Ya generé un número numero aleatorio");
                    session.setAttribute("aleatorio", modelo); 
                } else {                    
                    modelo = (AciertaModelo) session.getAttribute("aleatorio"); 
                }                
                
                if(modelo.comparar(num1)){
                    session.invalidate();
                    intentos = 0;
                    Cookie[] allCookies = request.getCookies(); 
                    Cookie cookie = null; 
                    boolean existeCookie = false;
                    for (Cookie tmp : allCookies) { 
                        if (tmp.getName().equals("juegosGanados")) {                        
                            existeCookie = true; 
                            int ganados = Integer.parseInt(tmp.getValue());    
                            ganados++; 
                            cookie = new Cookie("juegosGanados", ganados + "");  
                            break; 
                        } 
                    } 
                    if (!existeCookie) {  
                        cookie = new Cookie("juegosGanados", "0");      
                    }
                    response.addCookie(cookie); 
                    out.println("wasa");
                    response.sendRedirect("ganador.jsp"); 
                } else {
                    
                    request.getSession().setAttribute("intentos", intentos);
                    request.getRequestDispatcher("/perdedor.jsp").forward(request, response);                    
                }
            }else{
                    response.sendRedirect("error.jsp");
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
